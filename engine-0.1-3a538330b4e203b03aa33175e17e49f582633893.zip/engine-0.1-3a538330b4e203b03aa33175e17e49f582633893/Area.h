#pragma once
#include "TemplateTileset.h"

class Area
{
public:
	Area(int index);
	~Area();
private:

};

