#include "MainMenuScene.h"



MainMenuScene::MainMenuScene()
{
}


MainMenuScene::~MainMenuScene()
{
}

bool MainMenuScene::Initialize()
{
	return false;
}

void MainMenuScene::Update()
{
}

void MainMenuScene::Render(ID3D11DeviceContext * deviceContext, XMFLOAT4X4 viewMatrix, XMFLOAT4X4 projectionMatrix)
{
}
