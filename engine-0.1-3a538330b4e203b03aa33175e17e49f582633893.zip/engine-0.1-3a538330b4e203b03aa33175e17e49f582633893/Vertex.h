#pragma once
class Vertex
{
public:
	Vertex();
	~Vertex();
};

