#include "TemplateTileset.h"



TemplateTileset::TemplateTileset()
{
}


TemplateTileset::~TemplateTileset()
{
}
