#pragma once
class Skybox
{
public:
	Skybox();
	~Skybox();
};

