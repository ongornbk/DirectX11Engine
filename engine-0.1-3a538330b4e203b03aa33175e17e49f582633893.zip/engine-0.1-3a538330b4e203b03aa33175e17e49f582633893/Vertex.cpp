#include "Vertex.h"



Vertex::Vertex()
{
}


Vertex::~Vertex()
{
}
