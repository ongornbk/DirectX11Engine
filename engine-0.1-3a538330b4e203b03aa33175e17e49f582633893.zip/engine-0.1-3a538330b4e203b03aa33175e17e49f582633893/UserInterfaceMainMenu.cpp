#include "UserInterfaceMainMenu.h"



UserInterfaceMainMenu::UserInterfaceMainMenu(Engine* engine, Shader* shader)
{
}


UserInterfaceMainMenu::~UserInterfaceMainMenu()
{
}

void UserInterfaceMainMenu::Render(ID3D11DeviceContext * deviceContext, XMFLOAT4X4 viewMatrix, XMFLOAT4X4 projectionMatrix)
{
}

void UserInterfaceMainMenu::Update(XMVECTOR cameraPosition)
{
}

void UserInterfaceMainMenu::GetMousePosition(int & X, int & Y)
{
}
