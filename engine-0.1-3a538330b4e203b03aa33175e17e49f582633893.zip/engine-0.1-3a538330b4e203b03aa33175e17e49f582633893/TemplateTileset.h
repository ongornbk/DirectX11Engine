#pragma once
class TemplateTileset
{
public:
	TemplateTileset();
	~TemplateTileset();
};

