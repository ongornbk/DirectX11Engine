#include "Area.h"



Area::Area(int index)
{


}


Area::~Area()
{
}
