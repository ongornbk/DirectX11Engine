#pragma once
class FontShader
{
public:
	FontShader();
	~FontShader();
};

