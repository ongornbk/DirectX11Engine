#include "Walls.h"



Walls::Walls()
{
}


Walls::~Walls()
{
}
